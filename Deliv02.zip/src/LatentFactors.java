/* TU Delft
 * BSc Computer Science
 * TI2735-C Data Mining 2016-2017
 * Project Deliverable 02: Latent Factors
 */

import java.lang.System;
import java.util.Map;
import java.util.Random;

public class LatentFactors {
	
	public static void main(String[] args) {
		
		// Read user list
		UserList userList = new UserList();
		userList.readFile("data/users.csv");
		
		// Read movie list
		MovieList movieList = new MovieList();
		movieList.readFile("data/movies.csv");
		
		// Read rating list
		RatingList ratings = new RatingList();
		ratings.readFile("data/ratings.csv", userList, movieList);	

		// Make predictions file
		RatingList predRatings = new RatingList();
		predRatings.readFile("data/predictions.csv", userList, movieList);

		// Add ratings to user and movie lists
		userList.addRatings(ratings);
		movieList.addRatings(ratings);

		// Perform rating predictions
		predictRatings(userList, movieList, ratings, predRatings);

		// Write result file
		predRatings.writeResultsFile("submission.csv");
	}
	
	public static RatingList predictRatings(UserList userList,
			MovieList movieList, RatingList ratingList, RatingList predRatings) {

		// Number of users and movies
		int nU = userList.size();
		int nM = movieList.size();
		
		// Normalize ratings for every user separately
		...CODE HERE...
		// Number of factors
		int nF = 3;
		
		// Regularization parameters
		double lambdaQ = 1.0;
		double lambdaP = 1.0;
		
		// Optimization parameters
		double xTolerance = 0.0001;
		int maxIterations = 20;
		double RMSE_ = Double.POSITIVE_INFINITY;
		
		// Initialize random number generator
		Random rng = new Random();
		
		// Initialize factors
		Map<Integer,Map<Integer,Double>> Q = Util.initializeLatentFactor(nU,nF);
		Map<Integer,Map<Integer,Double>> P = Util.initializeLatentFactor(nM,nF);
				
		// Perform optimization
		..CODE HERE..
		
		
		// Loop over to-be-predicted ratings
		System.out.print("Running predictions..");
		for (int i=0; i<predRatings.size(); i++) {

			..CODE HERE..
			// Set predicted rating
			predRatings.get(i).setRating(prediction);
			
		}
		System.out.print("done.");

		// Return predictions
		return predRatings;
	}
}
